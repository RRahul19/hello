from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model


# Create your models here.


class details(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, default=" ")
    name = models.CharField(max_length=50)
    number = models.CharField(max_length=10)

    def __str__(self):
        return self.name
