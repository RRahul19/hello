from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .forms import SignUpForm,LoginForm
from django.contrib import messages
from django.contrib import auth
from .models import details
from django.core.exceptions import ValidationError
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from .serilaizers import detailSerializers
from django.contrib.auth.models import User
# Create your views here.

def home(request):
    return render(request, 'registration/base.html')


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect(details_required)

    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

def login_request(request):
    form = LoginForm()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect(details_required)
        else:
            messages.error(request, f'Invalid Username and Password')
            
    else:
        form = LoginForm()
        
    return render(request, 'registration/login.html', {'form': form})


def logout_request(request):
    auth.logout(request)
    return redirect(home)
    

def details_required(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('number'):
            d = details()
            d.user = request.user
            d.name = request.POST.get('name')
            d.number = request.POST.get('number')
            d.save()

    context ={
            'content': details.objects.filter(user=request.user),
        }
    return render(request, 'registration/det.html', context)

class API_objects(APIView):
    permission_classes = (IsAuthenticated,)
    queryset = details.objects.all()
    serializer_class = detailSerializers

class API_objects_details(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        user = User.objects.get(username=request.user.username)
        # user = CurrentUserDefault()
        queryset123 = details.objects.filter(username=user)
        serializer_class = detailSerializers

    # def list(self, request, user):
    #     queryset = self.get_queryset(self.get_queryset())
    # #     user = queryset.get(user=self.request.user)
    # #     serializer = detailSerializers(queryset, many=True)
    # #     return serializer["json"]
    # def get_queryset(self):
    #
    #     return details.objects.filter(user=self.request.user.username)

